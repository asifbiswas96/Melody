// MelodyPalette.kt
//
// Melody's approved palette (NeuroByte glass style, confirmed by the owner on 2026-11-14):
// dark navy base, blue/teal/violet glow behind the glass, sky and teal accents, near-white text.

package com.mochyy.mochymusic.ui.theme

import androidx.compose.ui.graphics.Color

/** The two navies the app's background is built from. */
val MelodyNavyDeep = Color(0xFF03050F)
val MelodyNavy = Color(0xFF060A1C)

/** Slightly lifted navy for variant surfaces (cards' base under the frost). */
val MelodySurfaceNavy = Color(0xFF0A1024)

/** The glow that moves slowly behind the glass. Never drawn as solid blocks. */
val MelodyGlowBlue = Color(0xFF1F4FC4)
val MelodyGlowTeal = Color(0xFF1FA7B8)
val MelodyGlowViolet = Color(0xFF6A4BD8)

/** Accents: sky for primary actions, teal for secondary (downloads etc.). */
val MelodyAccentSky = Color(0xFF6ECDFF)
val MelodyAccentTeal = Color(0xFF35D6C0)

/** Violet reads too dark unadjusted on navy; this is the on-glass version. */
val MelodyVioletBright = Color(0xFF8F74E8)

/** Text on glass: near-white primary, muted blue-grey secondary. */
val MelodyTextPrimary = Color(0xFFF4F7FF)
val MelodyTextSecondary = Color(0xFFAEBAD0)

/** Dark ink for text/icons sitting on the bright accents. */
val MelodyOnAccent = Color(0xFF06121F)
val MelodyOnTeal = Color(0xFF03211C)

/** Containers that pair with the accents in the Material scheme. */
val MelodySkyContainer = Color(0xFF122A4D)
val MelodyOnSkyContainer = Color(0xFFD9EEFF)
val MelodyTealContainer = Color(0xFF0E3A34)
val MelodyOnTealContainer = Color(0xFFD2FFF4)

/** Hairlines and outlines on the navy. */
val MelodyOutline = Color(0xFF3A4A66)
