// MelodyGlass.kt
//
// Melody Phase 2 - the shared glass design system: the moving-glow background and the reusable
// frosted surfaces (GlassSurface, GlassCard, GlassChip, GlassButton, GlassBottomBar,
// GlassMiniPlayer) that the screen phases build with.
//
// Frost rules, matching the approved style:
//  - charcoal navy glass that stays transparent enough for the glow behind to read,
//  - a 1dp lit edge (brighter at the top), soft bluish shadow,
//  - 24-28dp rounded corners on cards, full-round pills, 48dp minimum touch targets,
//  - text and controls are drawn above the glass, never blurred.
//
// Blur: where a GlassState is supplied, surfaces frost the real backdrop through the app's
// existing glass engine (Android 12+, and it already honours the "disable blur" setting and the
// blur-strength slider). Without one, or where the engine falls back, the same surface is a
// readable translucent tint - that is the Android 8-11 / low-end path.
//
// Motion gates: the glow stops (holds a static frame) when battery saver is on, when Android's
// "Remove animations" sets the animator scale to 0, and whenever the app is not RESUMED
// (screen off or in the background).

package com.mochyy.mochymusic.ui.component

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.mochyy.mochymusic.ui.theme.MelodyAccentSky
import com.mochyy.mochymusic.ui.theme.MelodyAccentTeal
import com.mochyy.mochymusic.ui.theme.MelodyGlowBlue
import com.mochyy.mochymusic.ui.theme.MelodyGlowTeal
import com.mochyy.mochymusic.ui.theme.MelodyGlowViolet
import com.mochyy.mochymusic.ui.theme.MelodyNavyDeep

import com.mochyy.mochymusic.ui.theme.MelodyTextPrimary
import com.mochyy.mochymusic.ui.theme.MelodyTextSecondary
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** Card corners from the approved mockups. */
val MelodyCardCorner = 24.dp
val MelodyCardCornerLarge = 28.dp

/** Chips and buttons are full-round pills. */
val MelodyPillShape = RoundedCornerShape(percent = 50)

/** Every interactive surface is at least this tall/wide. */
val MelodyMinTouchTarget = 48.dp

/**
 * The frosted fill: a charcoal navy at ~62%. Dark enough that white text keeps its contrast,
 * transparent enough that the glow behind the glass still shapes it.
 */
val MelodyGlassTint = Color(0xFF101A30).copy(alpha = 0.62f)

/** What the glass sits on where there is no real backdrop to blur. */
private val MelodyGlassFoundation = MelodyNavyDeep.copy(alpha = 0.55f)

/** The lit edge: catches light at the top, all but gone at the bottom. */
val MelodyGlassEdgeBrush: Brush = Brush.verticalGradient(
    0f to Color.White.copy(alpha = 0.14f),
    0.25f to Color.White.copy(alpha = 0.08f),
    1f to Color.White.copy(alpha = 0.04f),
)

// ---------------------------------------------------------------------------------------------
// Motion gates
// ---------------------------------------------------------------------------------------------

/**
 * Whether Melody's ambient motion (the background glow) may move right now.
 *
 * Recomputed on every lifecycle event, so turning the screen off, backgrounding the app or the
 * system flipping battery saver while the app is open all settle on the next event. The animator
 * duration scale is read directly: 0 is Android's "Remove animations".
 */
@Composable
fun rememberMelodyMotionAllowed(): Boolean {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var allowed by remember { mutableStateOf(true) }
    DisposableEffect(lifecycleOwner) {
        val compute = {
            val animationsRemoved = try {
                android.provider.Settings.Global.getFloat(
                    context.contentResolver,
                    android.provider.Settings.Global.ANIMATOR_DURATION_SCALE,
                    1f,
                ) == 0f
            } catch (e: Exception) {
                false
            }
            val powerManager =
                context.getSystemService(android.content.Context.POWER_SERVICE) as? android.os.PowerManager
            val batterySaver = powerManager?.isPowerSaveMode == true
            val resumed = lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)
            !animationsRemoved && !batterySaver && resumed
        }
        allowed = compute()
        val observer = LifecycleEventObserver { _, _ -> allowed = compute() }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    return allowed
}

// ---------------------------------------------------------------------------------------------
// Background glow
// ---------------------------------------------------------------------------------------------

private val TwoPi = (2 * PI).toFloat()

/** One full drift cycle of the glow, slow enough to read as ambience, not animation. */
private const val GlowCycleMs = 28000

/** The frame the glow holds wherever motion is gated. */
private const val StaticGlowPhase = 0.35f

@Composable
private fun rememberGlowPhase(): () -> Float {
    if (!rememberMelodyMotionAllowed()) {
        return remember { { StaticGlowPhase } }
    }
    val transition = rememberInfiniteTransition(label = "melodyGlow")
    val phase = transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(GlowCycleMs, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "melodyGlowPhase",
    )
    // read only while drawing, so a ticking phase repaints without recomposing
    return { phase.value }
}

private fun DrawScope.glowBlob(center: Offset, radius: Float, color: Color) {
    if (radius <= 0f) return
    drawCircle(
        brush = Brush.radialGradient(
            0f to color,
            1f to Color.Transparent,
            center = center,
            radius = radius,
        ),
        radius = radius,
        center = center,
    )
}

private fun DrawScope.drawMelodyGlow(phase: Float) {
    val w = size.width
    val h = size.height
    if (w <= 0f || h <= 0f) return
    val t = phase * TwoPi
    val drift = 0.09f
    // blue, high and to the left
    glowBlob(
        center = Offset(w * (0.22f + drift * sin(t)), h * (0.16f + drift * cos(t))),
        radius = w * 0.95f,
        color = MelodyGlowBlue.copy(alpha = 0.42f),
    )
    // violet, right and lower, moving against the blue
    glowBlob(
        center = Offset(w * (0.85f - drift * cos(t * 0.8f + 1.3f)), h * (0.55f + drift * sin(t * 0.8f + 1.3f))),
        radius = w * 0.85f,
        color = MelodyGlowViolet.copy(alpha = 0.34f),
    )
    // teal, low left, the slowest of the three
    glowBlob(
        center = Offset(w * (0.15f + drift * cos(t * 0.6f + 2.6f)), h * (0.90f - drift * sin(t * 0.6f + 2.6f))),
        radius = w * 0.80f,
        color = MelodyGlowTeal.copy(alpha = 0.26f),
    )
}

/**
 * Draws Melody's moving glow behind whatever this modifier is attached to. The base colour is
 * NOT painted here: the root already paints the theme's surface, and the pure-black setting keeps
 * its plain black (pass `enabled = false` there).
 */
@Composable
fun Modifier.melodyGlowBackground(enabled: Boolean = true): Modifier {
    if (!enabled) return this
    val phase = rememberGlowPhase()
    return this.drawBehind { drawMelodyGlow(phase()) }
}

/**
 * The standalone background (base navy + glow), for previews and for screens the later phases
 * put it behind directly.
 */
@Composable
fun MelodyBackground(modifier: Modifier = Modifier, baseColor: Color = MelodyNavyDeep) {
    Box(modifier = modifier.background(baseColor).melodyGlowBackground(true))
}

// ---------------------------------------------------------------------------------------------
// Glass surfaces
// ---------------------------------------------------------------------------------------------

/**
 * The base frosted surface. With a [glassState] it frosts the real backdrop through the app's
 * glass engine (Android 12+, honouring the blur settings); otherwise it falls back to the
 * translucent tint. Content is laid out above the glass, so text and controls stay sharp.
 */
@Composable
fun GlassSurface(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(MelodyCardCorner),
    glassState: GlassState? = null,
    blurRadius: Float = 28f,
    tint: Color = MelodyGlassTint,
    contentColor: Color = MelodyTextPrimary,
    content: @Composable BoxScope.() -> Unit,
) {
    CompositionLocalProvider(LocalContentColor provides contentColor) {
        Box(
            modifier = modifier
                .shadow(
                    elevation = 8.dp,
                    shape = shape,
                    clip = false,
                    ambientColor = Color.Black.copy(alpha = 0.5f),
                    spotColor = MelodyGlowBlue.copy(alpha = 0.3f),
                )
                .clip(shape)
                .border(1.dp, MelodyGlassEdgeBrush, shape),
        ) {
            if (glassState != null) {
                GlassPillBackground(
                    state = glassState,
                    blurRadius = { blurRadius },
                    tint = tint,
                    foundationColor = MelodyGlassFoundation,
                    tileMode = android.graphics.Shader.TileMode.CLAMP,
                    modifier = Modifier.matchParentSize(),
                )
            } else {
                Box(Modifier.matchParentSize().background(tint))
            }
            content()
        }
    }
}

/**
 * A glass card. With [onClick] the whole card is one at-least-48dp touch target and the press
 * ripple is clipped to its corners.
 */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    shape: Shape = RoundedCornerShape(MelodyCardCorner),
    glassState: GlassState? = null,
    contentPadding: PaddingValues = PaddingValues(16.dp),
    content: @Composable BoxScope.() -> Unit,
) {
    val clickableModifier = if (onClick != null) {
        Modifier
            .defaultMinSize(minHeight = MelodyMinTouchTarget)
            .clickable(onClick = onClick)
    } else {
        Modifier
    }
    GlassSurface(
        modifier = modifier.then(clickableModifier),
        shape = shape,
        glassState = glassState,
    ) {
        Box(Modifier.padding(contentPadding)) { content() }
    }
}

/**
 * A filter/mood chip. Selected reads as lit teal glass; unselected stays quiet frost. The touch
 * target expands to 48dp without inflating the chip itself.
 */
@Composable
fun GlassChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val fill = if (selected) MelodyAccentTeal.copy(alpha = 0.22f) else MelodyGlassTint
    val edge = if (selected) {
        Brush.verticalGradient(
            0f to MelodyAccentTeal.copy(alpha = 0.8f),
            1f to MelodyAccentTeal.copy(alpha = 0.35f),
        )
    } else {
        MelodyGlassEdgeBrush
    }
    val textColor = if (selected) Color(0xFFD9FFF7) else MelodyTextSecondary
    Box(
        modifier = modifier
            .minimumInteractiveComponentSize()
            .clip(MelodyPillShape)
            .background(fill)
            .border(1.dp, edge, MelodyPillShape)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 7.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = label,
            color = textColor,
            fontSize = 13.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
        )
    }
}

/**
 * Buttons. Primary is the bright sky pill with dark ink (the blue buttons of the approved look);
 * secondary stays glass with a sky label.
 */
@Composable
fun GlassButton(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    primary: Boolean = true,
) {
    if (primary) {
        Box(
            modifier = modifier
                .defaultMinSize(minHeight = MelodyMinTouchTarget)
                .clip(MelodyPillShape)
                .background(
                    Brush.verticalGradient(
                        0f to MelodyAccentSky,
                        1f to Color(0xFF4FB4F0),
                    )
                )
                .clickable(onClick = onClick)
                .padding(horizontal = 24.dp, vertical = 12.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                text = label,
                color = Color(0xFF06121F),
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
            )
        }
    } else {
        Box(
            modifier = modifier
                .defaultMinSize(minHeight = MelodyMinTouchTarget)
                .clip(MelodyPillShape)
                .background(MelodyGlassTint)
                .border(1.dp, MelodyGlassEdgeBrush, MelodyPillShape)
                .clickable(onClick = onClick)
                .padding(horizontal = 24.dp, vertical = 12.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                text = label,
                color = MelodyAccentSky,
                fontWeight = FontWeight.SemiBold,
                fontSize = 15.sp,
            )
        }
    }
}

/**
 * The floating bottom bar's glass container, in the chrome tint the current nav bar already
 * draws with. Phase 3 wires it to the navigation items.
 */
@Composable
fun GlassBottomBar(
    modifier: Modifier = Modifier,
    glassState: GlassState? = null,
    content: @Composable RowScope.() -> Unit,
) {
    GlassSurface(
        modifier = modifier,
        shape = RoundedCornerShape(MelodyCardCornerLarge),
        glassState = glassState,
        blurRadius = 48f,
        tint = GlassChromeColor.copy(alpha = 0.78f),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .defaultMinSize(minHeight = 56.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceEvenly,
        ) {
            content()
        }
    }
}

/**
 * The floating mini player's glass container, matching the bottom bar. Phase 3 wires it to
 * playback; this phase deliberately touches no player logic.
 */
@Composable
fun GlassMiniPlayer(
    modifier: Modifier = Modifier,
    glassState: GlassState? = null,
    content: @Composable RowScope.() -> Unit,
) {
    GlassSurface(
        modifier = modifier,
        shape = RoundedCornerShape(MelodyCardCorner),
        glassState = glassState,
        blurRadius = 48f,
        tint = GlassChromeColor.copy(alpha = 0.78f),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .defaultMinSize(minHeight = 64.dp)
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            content()
        }
    }
}
